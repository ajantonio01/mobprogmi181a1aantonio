package com.example.flappybird3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ListView lv;

    String[] strings = {"Rank          Name          Score", "1              Adrian          60",
            "2              John            18", "3              Antonio        10",
            "4              Ismael          9", "5              Ebrada         7",
            "6              Peter           6","7              Elboy           5",
            "8              Rose            4","9              Andy           3",
            "10            Oniichan       1"};
    ArrayAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lv = (ListView) findViewById(R.id.listView);

        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, strings);

        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(MainActivity.this, "" + strings[1],
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
